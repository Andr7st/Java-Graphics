package paquete;
/**
 * Ejemplo dado en una clase de programación con pildorasinformaticas.
 */


import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.awt.event.*;
import java.util.*;

public class Clase1 {

    public Clase1(){

        ActionListener ya = new DameHora();
        /**
         * Otra forma de invocar a DameHora.
         * Hora ya = new DameHora();
         */
        Timer temporizador = new Timer(5000, ya);
        //
        temporizador.start();
        // Presionar para continuar a Finalizar proceso.
        //JOptionPane.showConfirmDialog(null, "Pulsa aceptar para parar");

        JOptionPane.showConfirmDialog(null,"Stop/Parar?", "ejecución", JOptionPane.DEFAULT_OPTION);
        
        System.exit(0); // Finalizar proceso.
    }
    
}

class DameHora implements ActionListener {

    public void actionPerformed(ActionEvent accion){
        Date now = new Date();
        System.out.println("Hora actual " + now);
    }
}