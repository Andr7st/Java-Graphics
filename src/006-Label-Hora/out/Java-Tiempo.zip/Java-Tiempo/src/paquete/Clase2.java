package paquete;
/**
 * @author Andr7st
 * Obteniendo la hora del sistema.
 */

import java.util.Calendar;
import java.util.GregorianCalendar;

public class Clase2 {
    
    private int hora;
    private int minuto;
    private int segundo;

    private String strTiempo; // Se usa para obtener la hora y usarla en interfaz grafica.

    public Clase2(){

        Calendar tiempo = new GregorianCalendar();
        this.hora    = tiempo.get(Calendar.HOUR_OF_DAY);
        this.minuto  = tiempo.get(Calendar.MINUTE);
        this.segundo = tiempo.get(Calendar.SECOND);
    }

    public void HoraCruda(){
        // Imprimir la hora tal y como es capturada del sistema.
        System.out.println(hora + ":" + minuto + ":" + segundo);
    }

    public void HoraMeridiana(){
        /**
         * Representación de la hora del sistema con AM-PM.
         */
        String meridiano = "AM";
        String segCero = "";
        String minCero = "";
        // Cambiando AM/PM
        if (hora > 12){hora = (hora - 12); meridiano = "PM";}
        // anteponiendo cero para mostrar 1:07:07 en vez de 1:7:7
        if(segundo < 10){segCero = "0";}
        if(minuto < 10) {minCero = "0";}
        // Imprimir
       // System.out.println(hora + ":" + minCero + minuto + ":" + segCero +  segundo + " " + meridiano);

        this.strTiempo = hora + ":" + minCero + minuto + ":" + segCero +  segundo + " " + meridiano;
    }

    public String dameTiempo(){
        return strTiempo;
    }
}