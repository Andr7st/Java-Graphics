package paquete;
/**
 * @author Andrés Segura
 * @author Andr7st
 * Ejercicio, obtener la hora.
 */

import javax.swing.JOptionPane;
import javax.swing.Timer;
import java.awt.event.*;
import java.util.*;


public class Main {
    public static void main(String[] args) {

        ActionListener ya = new DameHora2();
        /**
         * Otra forma de invocar a DameHora.
         * Hora ya = new DameHora();*/
         
        Timer temporizador = new Timer(1000, ya);
        //
        temporizador.start();
        // Presionar para continuar a Finalizar proceso.
        //JOptionPane.showConfirmDialog(null, "Pulsa aceptar para parar");

        JOptionPane.showConfirmDialog(null,"Stop/Parar?", "ejecución", JOptionPane.DEFAULT_OPTION);
        
        System.exit(0); // Finalizar proceso.
    }
}


class DameHora2 implements ActionListener {

    public void actionPerformed(ActionEvent accion){

        Clase2 c2 = new Clase2();
        c2.HoraMeridiana();
        System.out.println(c2.dameTiempo());
        
    }
}